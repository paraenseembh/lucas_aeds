#include <stdio.h>
#include <stdlib.h>

/*Implemente um programa denominado Combinador, que recebe duas strings e deve combiná-las, 
alternando as letras de cada string, come¸cando com a primeira letra da primeira string, 
seguido pela primeira letra da segunda string,
em seguida pela segunda letra da primeira string, 
e assim sucessivamente.
As letrasr estantes da cadeia mais longa devem ser adicionadas
ao fim da string resultante e retornada.*/


int main(){

    void combina(char *a, char *b){
        
    }

    char a[100], b[100];
    int tam;
    while(scanf(" %s %s", a, b) != EOF){
        for(int i =0; i < a.lenght; i++){

        }
        printf("%s E %s", a, b);
    }
    
    return 0;
}