import java.util.*;

/*
//Imprimir números em sequência é uma tarefa relativamente simples. 
Mas e quando se trata de uma sequência espelho? Essa é uma sequência 
que possui um número inicial e um número final, e todos os números entre eles, 
inclusive, são dispostos em ordem crescente, 
sem espaços, e então essa sequência é refletida de forma invertida, 
como um reflexo no espelho. P reflexo no espelho. Por exemplo, se a sequência for de 7 a 12, o 
resultado seria 789101112211101987.or exemplo, se a sequência for de 7 a 12, o 
resultado seria 789101112211101987.

Escreva um programa que, dados dois números inteiros, imprima a respectiva sequência espelho.
*/
public class Q2{

    public static String espelho(int a, int b){
        String espelho = "";

        for (int i = a; i <= b; i++){
            espelho = espelho + i;
        }
        for (int j = (espelho.length()-1); j >= 0; j--){
            
            espelho = espelho + espelho.charAt(j);

            /*if (j < 100){
                if(j/10 > 0 )
                    temp2 = "" + (j%10) + (j/10);
                else
                    temp2 = "" + (j%10);
                    espelho = espelho + temp2;
            }
            else{
                if (j/10 >= 10){ 
                    temp2 = "" + (j%100) + (j%10) + (j/10);}
                else{
                    temp2 = "" + (j%10);
                    espelho = espelho + temp2;
                }
                
                }
            }*/
 
        }
        return espelho;
    }


        
    
    public static void main (String [] args){
        Scanner scanner = new Scanner(System.in);
        int a =0; int b =0; 
        while(scanner.hasNext()){
        a = scanner.nextInt();
        b = scanner.nextInt();
        System.out.println(espelho(a,b));
        }

        scanner.close();
    }

}

